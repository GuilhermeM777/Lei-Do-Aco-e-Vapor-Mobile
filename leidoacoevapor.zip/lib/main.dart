import 'package:flutter/material.dart';
import 'menu_screen.dart';
import 'personagens_screen.dart';
import 'fases_screen.dart';
import 'historia_screen.dart';
import 'dicas_screen.dart';
import 'musica_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lei do Aço e Vapor',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: Colors.brown,
        colorScheme: ColorScheme.fromSwatch().copyWith(
          secondary: Colors.amberAccent,
          brightness: Brightness.dark,
          surface: Colors.grey[900],
        ),
        textTheme: const TextTheme(
          bodyMedium: TextStyle(color: Colors.amberAccent),
        ),
        buttonTheme: const ButtonThemeData(
          buttonColor: Colors.brown,
          textTheme: ButtonTextTheme.primary,
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const MenuScreen(), // Adicionando const
        '/personagens': (context) => PersonagensScreen(),
        '/fases': (context) => const FasesScreen(),
        '/historia': (context) => const HistoriaScreen(),
        '/dicas': (context) => const DicaScreen(),
        '/musica': (context) => const MusicaScreen(),
      },
    );
  }
}
