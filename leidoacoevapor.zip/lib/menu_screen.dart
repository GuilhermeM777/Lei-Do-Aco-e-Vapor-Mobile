import 'package:flutter/material.dart';

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('imagens/fundo.png'),
            fit: BoxFit.cover, // Ajusta a imagem para preencher toda a tela
          ),
        ),
        child: Stack(
          children: [
            // Alinhamento do logo no canto superior esquerdo
            Positioned(
              top: -25.0,
              left: 10.0,
              child: Image.asset(
                'imagens/Logo.png', // Caminho do logo
                height: 200,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  return const Icon(Icons.error, size: 100, color: Colors.red);
                },
              ),
            ),
            // Conteúdo principal no centro da tela
            const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start, // Alinhado ao topo
                children: [
                  SizedBox(height: 180.0), // Aumenta o espaço acima do título
                  Text(
                    'Lei do Aço e Vapor',
                    style: TextStyle(
                      fontSize: 32.0,
                      fontWeight: FontWeight.bold,
                      color: Color(0x7b000000),
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 10.0), // Espaço abaixo do título
                ],
              ),
            ),
            // Botões posicionados na parte inferior da tela
            Positioned(
              bottom: 140.0, // Ajusta a posição superior dos botões
              left: 0,
              right: 0,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildMenuButton(context, 'Personagens', '/personagens'),
                  const SizedBox(height: 20.0),
                  _buildMenuButton(context, 'Fases', '/fases'),
                  const SizedBox(height: 20.0),
                  _buildMenuButton(context, 'História', '/historia'),
                  const SizedBox(height: 20.0),
                  _buildMenuButton(context, 'Dicas', '/dicas'),
                  const SizedBox(height: 20.0),
                  _buildMenuButton(context, 'Músicas', '/musica'),
                  const SizedBox(height: 20.0),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuButton(BuildContext context, String text, String route) {
    return ElevatedButton.icon(
      onPressed: () {
        Navigator.pushNamed(context, route);
      },
      icon: const Icon(Icons.stars, size: 24, color: Colors.amberAccent),
      label: Text(text),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.brown, // Substituindo 'primary'
        foregroundColor: Colors.amberAccent, // Substituindo 'onPrimary'
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        textStyle: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
