import 'package:flutter/material.dart';
import 'fases_detalhes_screen.dart';

class FasesScreen extends StatelessWidget {
  const FasesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final List<String> fases = [
      'Fase 1',
      'Fase 2',
      'Fase 3',
      'Fase 4',
      'Fase 5',
      'Fase 6',
    ];

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('imagens/fundo.png'),
            fit: BoxFit.cover, // Ajusta a imagem para preencher toda a tela
          ),
        ),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: fases.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => FaseDetalhesScreen(
                            faseNome: fases[index],
                          ),
                        ),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.all(15.0),
                      margin: const EdgeInsets.symmetric(vertical: 8.0),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                        child: Text(
                          fases[index],
                          style: const TextStyle(
                            fontSize: 18.0,
                            color: Colors.amberAccent,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Volta para a tela anterior
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.brown, // Substitui 'primary'
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'Voltar',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.amberAccent,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
