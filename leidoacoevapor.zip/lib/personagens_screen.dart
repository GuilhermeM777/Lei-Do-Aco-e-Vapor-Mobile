import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

// Classe Base para Personagens
class PersonagemBase {
  final String image;
  final String name;
  final String description;

  PersonagemBase({
    required this.image,
    required this.name,
    required this.description,
  });
}

// Classe Derivada de PersonagemBase
class Personagem extends PersonagemBase {
  Personagem({
    required String image,
    required String name,
    required String description,
  }) : super(image: image, name: name, description: description);
}

// Tela de Personagens
class PersonagensScreen extends StatelessWidget {
  // Construtor sem 'const'
  PersonagensScreen({super.key});

  // Lista de Personagens
  final List<Personagem> personagens = [
    Personagem(
      image: 'imagens/Protagonista.png',
      name: 'Forasteiro',
      description:
          'O Forasteiro é o protagonista do jogo, sendo o xerife de sua cidade natal que acabou de ser devastada por completo pelo Doc Holliday, duque da cidade móvel Saint Louis, e agora em busca de vingança alimentado pelo ódio e tristeza dentro de si, ele não irá parar até a morte do duque.',
    ),
    Personagem(
      image: 'imagens/Barman.png',
      name: 'Dylan Kelly',
      description:
          'Um homem de pele morena, cabelos castanhos, bigode e costeletas utiliza roupas finas da cor azul, sua personalidade é calma, trazendo certa tranquilidade para o jogador, o ajudando com informações que podem ser úteis',
    ),
    Personagem(
      image: 'imagens/Mercenarios.png',
      name: 'Mercenários',
      description:
          'Sendo o primeiro inimigo, suas roupas tem um tema simples e sujo com furos e rasgos, tem um comportamento bem agressivo, que aproveitam de sua quantidade para poder atacar o protagonista',
    ),
    Personagem(
      image: 'imagens/BufaloBill.png',
      name: 'Bufallo Bill',
      description:
          'Bufallo Bill é um homem gordinho com cabelos ruivos usando botas de couro que fica montado em cima de um bufallo e junto com ele ataca o mesmo para conseguir acabar com o protagonista em conjunto',
    ),
    Personagem(
      image: 'imagens/Mordomo.png',
      name: 'Mordomos',
      description:
          'Os mordomos são robôs que servem as pessoas dentro do trem, porém ao detectar a presença de alguém que não é convidado se tornam robôs mortiféros',
    ),
    Personagem(
      image: 'imagens/Lampadinhas.png',
      name: 'Lampadinhas',
      description:
          'As Lampadinhas têm um design propositalmente mais inofensivo, porém são bem agressivas quando o personagem acorda elas.',
    ),
    Personagem(
      image: 'imagens/Simao.png',
      name: 'Simão',
      description:
          'Simão é um dos chefes de segurança do departamento junto com seu marido João utilizam de distância e curta distância para atacar, enquanto Simão ataca de longa distância com seu rifle.',
    ),
    Personagem(
        image: 'imagens/Joao.png',
        name: 'João',
        description:
            'João sendo marido de Simão e o outro chefe do departamento de segurança, possuí ataques letais que mescla junto com sua capoeira, assim fazendo contraste com simão que utiliza do combate a longa distância para assistenciar seu marido.'),
    Personagem(
        image: 'imagens/Gaius.png',
        name: 'O Maquinista',
        description:
            'O Maquinista é uma máquina antiga que sempre foi responsável por controlar a ferroviária de Saint Louis, sendo um robô bem quieto, porém, fica basante agressivo na presença de pessoas que ameaçem tudo a sua volta, principalmente ele mesmo.'),
    Personagem(
        image: 'imagens/Duque.png',
        name: 'Duque DocHolliday',
        description:
            ' O Duque Doc Holliday é um homem que esbanja seu visual excêntrico com toques de arrogância e riqueza acumulada, se mostrando bem jovem e já tendo um incrível monopólio detém grande poder em cima das pessoas e sua influência nas mesmas, vemos isso em suas vestes sociais, tendo uma feição de alguém que provavelmente não tem um pingo de sanidade.')
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('imagens/fundo.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: SingleChildScrollView(
          child: Center(
            child: Column(
              children: [
                // Slider de Personagens
                CarouselSlider(
                  options: CarouselOptions(
                    height: 600.0,
                    enlargeCenterPage: true,
                    autoPlay: true,
                    autoPlayInterval: const Duration(seconds: 3),
                    aspectRatio: 16 / 9,
                    enableInfiniteScroll: true,
                    viewportFraction: 0.8,
                  ),
                  items: personagens.map((personagem) {
                    return Builder(
                      builder: (BuildContext context) {
                        return Container(
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.7),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Colors.amberAccent,
                              width: 3,
                            ),
                          ),
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            children: [
                              Container(
                                width: 200,
                                height: 200,
                                child: Image.asset(
                                  personagem.image,
                                  fit: BoxFit.fitWidth,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                personagem.name,
                                style: const TextStyle(
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'PixelFont',
                                ),
                              ),
                              const SizedBox(height: 5),
                              Text(
                                personagem.description,
                                style: const TextStyle(
                                  fontSize: 16.0,
                                  fontFamily: 'PixelFont',
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 5),
                // Botão de Voltar ao Menu
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.brown,
                    foregroundColor: Colors.amberAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 10,
                    ),
                    textStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  child: const Text('Voltar ao Menu'),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
