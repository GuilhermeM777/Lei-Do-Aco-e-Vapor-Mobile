import 'package:flutter/material.dart';

class HistoriaScreen extends StatefulWidget {
  const HistoriaScreen({super.key});

  @override
  _HistoriaScreenState createState() => _HistoriaScreenState();
}

class _HistoriaScreenState extends State<HistoriaScreen> {
  String? selectedHistoria;

  final List<String> historias = [
    'História Principal',
    'História Bufalo Bill',
    'História Para-Raio',
    'História Simão e João',
    'História Maquinista',
  ];

  final Map<String, String> historiaContent = {
    'História Principal':
        'Após ter a sua cidade natal inteira destruída pelo Duque da cidade móvel conhecida como Saint Louis, o Forasteiro (Protagonista) procura vingança e irá passar por tudo e todos para conseguir a vingança por sua família e cidade que foi completamente destruída.',
    'História Bufalo Bill':
        'Bufalo Bill foi uma criança que nasceu sempre eu meio a viagens e situações de extrema pobreza o que sempre forçou a caçar, trabalhar e ajudar tudo em sua comumidade para viver nesse mundo em ruínas, e desde cedo em um dia de uma excursão sua em busca de comida achou um pequeno animal ferido em um canto escondido, e após cuidar dele começou a criar um grande vínculo com o mesmo, ficando bastante amigos e praticamente insuperáveis.',
    'História Para-Raio':
        'Para Raio foi uma pessoa que teve muito azar na sua origem, com o mundo acabando e os pobres deixados na terra para morrer, sendo uma gênia inventora nasceu em um lugar muito pobre o que fez ela ser bem atrassada em seus projetos, e pela escassez de equipamentos e a precaridade dos que tem, em suas primeiras invenções ela veio a matar seus pais e foi adotada pelo Duque, que a usou para criar uma grande parte de Saint Louis e tudo dentro dela, além de alguns equipamentos, como a arma do Simão e dos Seguranças.',
    'História Simão e João':
        'Simão e João possuem uma história de amor que vem de muito tempo atrás, com João aos seu 10 anos saindo do Brasil em busca de uma vida melhor e Simão um garoto nascido nos Estados Unidos com muito problemas com seus pais e irmãos, João foi como luz em sua vida, e desde cedo tiveram uma ligação mais forte do que aço e foram desenvolvendo isso e construindo a vida até se encontrar com Duque, que percebeu a força de João e a mira e agilidade de Simão e decidiu que seriam perfeito para trablhar com ele.',
    'História Maquinista':
        'O Maquinista foi a primeira invenção da Para Raio após Duque adotar ela, sendo a primeira a ser um sucesso total, com múltiplas funções, podendo falar, ajudar nas construções, atacar, e ter consciência própria para pode fazer o que quisesse e ele mesmo escolheu a profissão de Maquinista, com seu nome de verdade sendo Gaius, desde o começo de sua criação era ficcionado em trens que via nos livros da Para Raio. ',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('imagens/fundo.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: selectedHistoria == null
                    ? ListView.builder(
                        padding: const EdgeInsets.all(20.0),
                        itemCount: historias.length,
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedHistoria = historias[index];
                              });
                            },
                            child: Container(
                              margin:
                                  const EdgeInsets.symmetric(vertical: 10.0),
                              padding: const EdgeInsets.all(12.0),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.7),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                    color: Colors.amberAccent, width: 2),
                              ),
                              child: Center(
                                child: Text(
                                  historias[index],
                                  style: const TextStyle(
                                    fontSize: 20.0,
                                    color: Colors.amberAccent,
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      )
                    : Container(
                        padding: const EdgeInsets.all(20.0),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.7),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              selectedHistoria!,
                              style: const TextStyle(
                                fontSize: 24.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.amberAccent,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 20),
                            Text(
                              historiaContent[selectedHistoria]!,
                              style: const TextStyle(
                                fontSize: 16.0,
                                color: Colors.amberAccent,
                              ),
                              textAlign: TextAlign.justify,
                            ),
                            const SizedBox(height: 20),
                            ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  selectedHistoria = null; // Limpa a seleção
                                });
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.brown,
                                foregroundColor: Colors.amberAccent,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 10),
                                textStyle: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              child: const Text('Voltar às Histórias'),
                            ),
                          ],
                        ),
                      ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.brown,
                  foregroundColor: Colors.amberAccent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  textStyle: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onPressed: () {
                  Navigator.pop(context); // Volta para o Menu
                },
                child: const Text('Voltar ao Menu'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
