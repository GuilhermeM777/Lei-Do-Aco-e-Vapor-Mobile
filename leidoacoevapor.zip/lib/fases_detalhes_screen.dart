import 'package:flutter/material.dart';
import 'BaseScreen.dart';

class FaseDetalhesScreen extends BaseScreen {
  final String faseNome;

  FaseDetalhesScreen({Key? key, required this.faseNome})
      : super(
          key: key,
          title: faseNome,
          content: _buildFaseContent(faseNome),
        );

  static Widget _buildFaseContent(String faseNome) {
    if (faseNome == 'Fase 1') {
      return Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(child: Image.asset('imagens/Fase1.1.png', height: 285)),
              const SizedBox(width: 25),
              Flexible(child: Image.asset('imagens/Fase1.2.png', height: 285)),
            ],
          ),
          const SizedBox(height: 25),
          _buildDescription(
              'Sendo o lugar onde comporta todos os moradores da cidade móvel, possuindo, bares, mercados, padarias, lavanderias, hospitais… entre muitas coisas, dividido por classes econômicas que vão subindo com uma crescente, sendo os pobres ficando no lugar mais baixo próximo a entrada da cidade, o meio da cidade já mais pro centro da mesma fica os de classe média, e o pico mais alto da cidade é composta pela maior classe social do departamento comunitário, tendo vários comércios distribuídos por todo canto, também variado da onde estão localizados, o único trem de St. Louis se localiza no centro da cidade junto a classe média. O protagonista se encontrará num bar perto da classe média, mas ainda estando junto dos pobres, um bar bem abandonado e fantasma, com canos nas paredes por todo lado e um vapor e fumaça cobrindo quase todo local. Dentro do bar se mostra ser algo bem vagabundo, com poucas mesas e cadeiras, lustres com partes faltando e outras simplesmente apagadas, um barman a frente limpando copos bem antigos, dando para perceber marcas de uso que não tem como serem limpadas, a madeira do lugar todo já apodrecendo, grande parte pelo vapor do lado de fora e outra por desgaste mesmo, vários buracos e tábuas quebradas.'),
        ],
      );
    } else if (faseNome == 'Fase 2') {
      return Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(child: Image.asset('imagens/Fase2.1.png', height: 285)),
              const SizedBox(width: 25),
              Flexible(child: Image.asset('imagens/Fase2.2.png', height: 285)),
              const SizedBox(width: 25),
              Flexible(child: Image.asset('imagens/Fase2.3.png', height: 285)),
            ],
          ),
          const SizedBox(height: 25),
          _buildDescription(
              'Indo de trem para o departamento da agropecuária, pode se vê um lugar que se destoa completamente da cidade, possuindo feno para todo lugar e terra nos chãos gelados de metal, no quão são complementados por canos enormes passando pelas paredes com vapor, e outros que levam água e comida para os animais, nos quais estão presos em gaiolas de metal com pouco espaço para vê-los, parecendo caixas gigantes de metal com alguns buracos e frestas, e um portão que parece ter uma mecânica hidráulica, de ponta a outra, tem muitas pessoas com grandes uniformes que parecem estar carregando caixas, outras guiando o gado, e outras até mesmo parecendo estar entrando na cidade móvel por uma porta que tem na lateral do departamento que leva ao exterior com mais animais. E mais acima por um lance de escadas duplas, tem uma sala que parece pertencer ao chefe desse departamento. Sua sala possui várias cabeças de búfalos empalhadas e de outros animais, com uma estética bem velho oeste, com bancos de couro da cor vermelha e uma vitrola que toca músicas que remete a uma época mais antiga, com a decoração toda em uma madeira bem escura'),
        ],
      );
    } else if (faseNome == 'Fase 3') {
      return Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(child: Image.asset('imagens/Fase3.1.png', height: 285)),
              const SizedBox(width: 25),
              Flexible(child: Image.asset('imagens/Fase3.2.png', height: 285)),
              const SizedBox(width: 25),
              Flexible(child: Image.asset('imagens/Fase3.3.png', height: 285)),
            ],
          ),
          const SizedBox(height: 25),
          _buildDescription(
              'Um lugar com um revestimento pesado de pedra, que pega o departamento inteiro, porém é bem simples, sem muitos elementos e nenhuma outra pessoa parece estar aí dentro, única coisa que dá pra se ver, são lâmpadas pequenas com braços e pernas metálicos, que passam pelas paredes e chão carregando fios, de tamanhos diferentes, com várias sendo de diversos tamanhos, com várias bobinas e postes de eletricidade por todo local, dando para se ver somente uma pessoa parecendo fazer vapor virar eletricidade mais a frente em uma mesa grande com vários componentes é uma daquelas lâmpadas mas muito pequena que parece estar auxiliando a mulher.'),
        ],
      );
    } else if (faseNome == 'Fase 4') {
      return Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(child: Image.asset('imagens/Fase4.1.png', height: 285)),
              const SizedBox(width: 25),
              Flexible(child: Image.asset('imagens/Fase4.2.png', height: 285)),
              const SizedBox(width: 25),
            ],
          ),
          const SizedBox(height: 25),
          _buildDescription(
              'O departamento de segurança tem uma aparência mais futurista como devia ser, possuindo metais de uma coloração escura na qual tem vários canos e válvulas, que aparecem ser algo relacionado a armários que tem ali, provavelmente tem como abri elas, nas paredes tem vários coletes que parecem ser de cobre, e possuem canos que saem de suas costas que podem ser para múltiplas funcionalidades, e tem vários soldados que estão navegando por todo o ambiente mas parecem estar ignorando o protagonista, para além disso, tem um segundo andar no qual possui mais portas que parecem estar separando várias coisas dentro do departamento, como armas mais pesadas, vestiários, uma sala para armazenar casos, e mais ao fundo do corredor com as portas, tem uma sala que parece ser a sala dos xerifes responsáveis por todos daí, o que é estranho, é a porta dessa sala que é divida pela metade, uma parte dela é estilizadas, tendo detalhes em branco e dourado, com rastros dourados parecendo de tiros, a outra parte é uma porta preta com vários desenhos de chamas com relevo de coloração roxa.'),
        ],
      );
    } else if (faseNome == 'Fase 5') {
      return Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(child: Image.asset('imagens/Fase5.1.png', height: 285)),
              const SizedBox(width: 25),
              Flexible(child: Image.asset('imagens/Fase5.2.png', height: 285)),
              const SizedBox(width: 25),
              Flexible(child: Image.asset('imagens/Fase5.3.png', height: 285)),
              const SizedBox(width: 25),
            ],
          ),
          const SizedBox(height: 25),
          _buildDescription(
              'Começando a fase do personagem saindo direto do departamento de segurança, pronto para pegar o trem de sempre para seguir para o próximo departamento a procura do Doc Holliday, porém, ao trem chegar na paragem, ele está completamente vazio, o protagonista ainda se surpreende de como as coisas são antiquadas referente ao mundo exterior, o trem é bem grande, parecendo ocupar bastante espaço no trilho, sendo um metal mais claro porém pela escuridão não parece assim tanto, com dois faróis bem grande iluminando todos os locais por qual passa, o que mais assusta no trem, é que ele sempre está saindo do vapor que ele mesmo faz, o camuflando, a longa distância só tem como ver a luz iluminando uma grande fumaça que o acompanha, o barulho é agonizante, com tantas engrenagens trabalhando, combinando com um barulho de vapor quente saindo dos encanamentos do trem, e barulhos de uma grande caldeira que pode ser o que dá combustível para o mesmo funcionar.'),
        ],
      );
    } else if (faseNome == 'Fase 6') {
      return Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(child: Image.asset('imagens/Fase6.1.png', height: 285)),
              const SizedBox(width: 25),
              Flexible(child: Image.asset('imagens/Fase6.2.png', height: 285)),
              const SizedBox(width: 25),
            ],
          ),
          const SizedBox(height: 25),
          _buildDescription(
              'Após passar por todos os departamentos, o protagonista sobe até o topo da cidade móvel, conseguindo chegar ao zepelim do barão Doc Holliday, vendo de perto um enorme zepelim dourado misturado com uma cor de cobre, que está preso a cidade móvel, uma escada menor leva para dentro do zepelim, em seu topo é possível ver uma aparência bem chique que remete a era vitoriana com elementos mecânicos e de Steampunk. Navegando por todo o zepelim, o jogador consegue achar uma sala um pouco mais estranha, na qual ele seguiu enquanto ouvia uma música tocando uma música clássica, parecendo ser bem antiga, ao entrar no corredor de onde está vindo a música, se vê um grande escritório que aparenta ser um pouco mais chique, com um homem parado na frente de um espelho imenso que tem no escritório.'),
        ],
      );
    }

    // Adicione outros casos para cada fase conforme necessário.
    return const SizedBox
        .shrink(); // Retorna um widget vazio caso não encontre a fase.
  }

  static Widget _buildDescription(String text) {
    return Expanded(
      child: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(16.0),
          color: Colors.black.withOpacity(0.7),
          child: Text(
            text,
            style: const TextStyle(fontSize: 16, color: Colors.amberAccent),
            textAlign: TextAlign.justify,
          ),
        ),
      ),
    );
  }
}
