import 'package:flutter/material.dart';

class DicaScreen extends StatelessWidget {
  const DicaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: DicaContent(), // Chamamos o widget separado para o conteúdo
    );
  }
}

class DicaContent extends StatelessWidget {
  const DicaContent({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('imagens/fundo.png'),
          fit: BoxFit.cover,
        ),
      ),
      child: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildTitulo('Fase 1'),
                const SizedBox(height: 20.0),
                _buildDicaList([
                  'Dica 1: Preste atenção no diálogo do barman para não perder nada que é necessário fazer.',
                  'Dica 2: Utilize o alcance de sua arma para conseguir derrotar os mercenários sem problema algum.',
                ]),
                const SizedBox(height: 30.0),
                _buildTitulo('Fase 2'),
                const SizedBox(height: 20.0),
                _buildDicaList([
                  'Dica 1: Com uma maior dificuldade, cuidado com seus corações de vida.',
                  'Dica 2: Use as habilidades especiais para derrotar o Bufallo Bill.',
                  'Dica 3: Utilize as plataformas para avançar na fase.',
                ]),
                const SizedBox(height: 30.0),
                _buildTitulo('Fase 3'),
                const SizedBox(height: 20.0),
                _buildDicaList([
                  'Dica 1: Cuidado ao se aproximar das lampadinhas, elas despertarão.',
                  'Dica 2: Desative os raios que podem te matar.',
                  'Dica 3: Aproveite os momentos de fraqueza da Para Raio.',
                ]),
                const SizedBox(height: 30.0),
                _buildTitulo('Fase 4'),
                const SizedBox(height: 20.0),
                _buildDicaList([
                  'Dica 1: Use as coberturas para lidar com apenas um dos chefes por vez.',
                  'Dica 2: É impossível atacar Simão. Use o dash para desviar das esferas.',
                ]),
                const SizedBox(height: 30.0),
                _buildTitulo('Fase 5'),
                const SizedBox(height: 20.0),
                _buildDicaList([
                  'Dica 1: Os mordomos são rápidos; mantenha-se atento.',
                  'Dica 2: Memorize os dois ataques principais do Maquinista.',
                ]),
                const SizedBox(height: 30.0),
                _buildTitulo('Fase 6'),
                const SizedBox(height: 20.0),
                _buildDicaList([
                  'Dica 1: Tome cuidado com ataques aéreos e terrestres do Duque.',
                  'Dica 2: Cuidado com as bombas arremessadas por ele, que causam dano em área.',
                ]),
                const SizedBox(height: 30.0),
                _buildVoltarButton(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTitulo(String titulo) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        border: Border.all(color: Colors.amberAccent, width: 2),
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.all(10.0),
      child: Text(
        titulo,
        style: const TextStyle(
          fontSize: 36.0,
          fontWeight: FontWeight.bold,
          color: Colors.amberAccent,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget _buildDicaList(List<String> dicas) {
    return Container(
      padding: const EdgeInsets.all(15.0),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        border: Border.all(color: Colors.amberAccent, width: 2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: dicas.map((dica) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 10.0),
            child: Text(
              dica,
              style: const TextStyle(
                fontSize: 16.0,
                color: Colors.amberAccent,
              ),
              textAlign: TextAlign.justify,
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildVoltarButton(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.brown,
        foregroundColor: Colors.amberAccent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        textStyle: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      onPressed: () {
        Navigator.pop(context); // Volta para o Menu
      },
      child: const Text('Voltar ao Menu'),
    );
  }
}
