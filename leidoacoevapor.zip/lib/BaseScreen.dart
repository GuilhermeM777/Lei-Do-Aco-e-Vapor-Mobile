import 'package:flutter/material.dart';

/// Classe base para telas com fundo e layout comuns.
abstract class BaseScreen extends StatelessWidget {
  final String title;
  final Widget content;

  const BaseScreen({Key? key, required this.title, required this.content})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('imagens/fundo.png'),
            fit: BoxFit.cover, // Ajusta a imagem para preencher toda a tela
          ),
        ),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildTitle(title),
            const SizedBox(height: 20),
            Expanded(child: content), // Conteúdo específico da tela
            const SizedBox(height: 20),
            _buildBackButton(context),
          ],
        ),
      ),
    );
  }

  // Método para construir o título estilizado.
  Widget _buildTitle(String text) {
    return Container(
      padding: const EdgeInsets.all(10.0),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        border: Border.all(color: Colors.amberAccent, width: 2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 24,
          color: Colors.amberAccent,
          fontWeight: FontWeight.bold,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  // Botão de voltar padrão.
  Widget _buildBackButton(BuildContext context) {
    return ElevatedButton(
      onPressed: () => Navigator.pop(context),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.brown,
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      child: const Text(
        'Voltar',
        style: TextStyle(
          fontSize: 18,
          color: Colors.amberAccent,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
