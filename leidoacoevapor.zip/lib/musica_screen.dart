import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

// Classe de Dados para os Bosses
class Boss {
  final String nome;
  final String descricao;
  final String imagem;
  final String audioUrl;

  Boss({
    required this.nome,
    required this.descricao,
    required this.imagem,
    required this.audioUrl,
  });
}

class MusicaScreen extends StatelessWidget {
  const MusicaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: MusicaBody(),
    );
  }
}

class MusicaBody extends StatelessWidget {
  final List<Boss> bosses = [
    Boss(
      nome: 'Buffalo Bill',
      descricao:
          'Para música do Bufallo Bill, tivemos que nos inspirar em algo puxado mais pro country, então utilizamos de violas para conseguir montar o ambiente, deixando de lado instrumentos que não fossem acústicos, usando também de gaitas, assim montado a música perfeita para o tema do boss.',
      imagem: 'imagens/BufaloBill.png',
      audioUrl:
          'https://www.dropbox.com/scl/fi/ufkt9r9gs1ucfuv923hpi/Musica_Boss__Bufalo_Bill.mp3?dl=1',
    ),
    Boss(
      nome: 'Para Raio',
      descricao:
          'Sendo uma das primeiras músicas feitas, foi pensado em algo agressivo que utlizazem elementos mais eletrônicos para tentar remeter toda a estética que a Para Raio e sua fase passam, usando de sons que simulassem raios e outros para tentar parecer algo mais tecnológico.',
      imagem: 'imagens/ParaRaio.png',
      audioUrl:
          'https://www.dropbox.com/scl/fi/xcwqr5fsxwv4ysxkie7mi/Bossfight_-_Para_Raio_-1.mp3?dl=1',
    ),
    Boss(
      nome: 'Simão e João',
      descricao:
          'Simão e João a primeira vista era para ter sido uma música com instrumentos mais diversificados, como o berimbau para remeter a vida capoeirista de João, porém, decidimos ir por outro caminho, transformando em um metal para fazer combinar mais com a luta e dar mais emoção para os jogadores.',
      imagem: 'imagens/JoaoSimao.png',
      audioUrl:
          'https://www.dropbox.com/scl/fi/mzeaitqq62r0zg980dgzk/Musica_do_Simao_e_Joao.mp3?dl=1',
    ),
    Boss(
      nome: 'O Maquinista',
      descricao:
          'Para a música do Maquinista, foi seguido a mesma lógica como a da Para Raio, contendo efeitos que remetam ao personagem como o vapor sendo liberado, indicando o vapor que o Maquinista repele e também o presente em sua sala, e foi feito um metal puxado para o industrial para dar um som mais metálico para a música.',
      imagem: 'imagens/Gaius.png',
      audioUrl:
          'https://www.dropbox.com/scl/fi/nyr02yam6znd0x6lt4i5b/Bossfight-Maquinista.mp3?dl=1',
    ),
    Boss(
      nome: 'Duque',
      descricao:
          'A música do Duque foi a mais complexa em quesito de composição por ser um gênero totalmente diferente das demais músicas, sendo puxado para um clássico que tivesse alguns elementos de rock, o que deu um trabalho de conseguir combinar, porém, vai trazer o lado de riqueza que o Duque exala e sua classe em combate e fora dele, mostrando o seu ar imponente e majestoso.',
      imagem: 'imagens/Duque.png',
      audioUrl:
          'https://www.dropbox.com/scl/fi/i23bwqth6v31tpwp3293t/Musica_Duque__Boss_Final-1.mp3?dl=1',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('imagens/fundo.png'),
          fit: BoxFit.cover,
        ),
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(20.0),
              itemCount: bosses.length,
              itemBuilder: (context, index) {
                final boss = bosses[index];
                return BossCard(boss: boss);
              },
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(20.0),
            child: VoltarMenuButton(),
          ),
        ],
      ),
    );
  }
}

class BossCard extends StatefulWidget {
  final Boss boss;

  const BossCard({super.key, required this.boss});

  @override
  _BossCardState createState() => _BossCardState();
}

class _BossCardState extends State<BossCard> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isPlaying = false;
  double _volume = 0.5;
  bool _isControlBarVisible = false;

  @override
  void initState() {
    super.initState();
    _audioPlayer.setVolume(_volume);
  }

  void _playPauseAudio() async {
    if (_isPlaying) {
      await _audioPlayer.pause();
    } else {
      await _audioPlayer.play(widget.boss.audioUrl);
    }
    setState(() {
      _isPlaying = !_isPlaying;
      _isControlBarVisible =
          true; // Mantém a barra visível mesmo quando pausado
    });
  }

  void _stopAudio() async {
    await _audioPlayer.stop();
    setState(() {
      _isPlaying = false;
      _isControlBarVisible = false;
    });
  }

  void _changeVolume(double value) {
    setState(() {
      _volume = value;
    });
    _audioPlayer.setVolume(_volume);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        GestureDetector(
          onTap: () {
            _playPauseAudio();
            setState(() {
              _isControlBarVisible = true; // Mostra a barra ao clicar
            });
          },
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 15.0),
            padding: const EdgeInsets.all(12.0),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.7),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.amberAccent, width: 2),
            ),
            child: Row(
              children: [
                Image.asset(
                  widget.boss.imagem,
                  height: 100,
                  width: 100,
                  fit: BoxFit.cover,
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.boss.nome,
                        style: const TextStyle(
                          fontSize: 24.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.amberAccent,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        widget.boss.descricao,
                        style: const TextStyle(
                          fontSize: 16.0,
                          color: Colors.amberAccent,
                        ),
                        textAlign: TextAlign.justify,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        if (_isControlBarVisible)
          Column(
            children: [
              IconButton(
                icon: Icon(_isPlaying ? Icons.pause : Icons.play_arrow),
                onPressed: _playPauseAudio,
              ),
              Slider(
                value: _volume,
                min: 0.0,
                max: 1.0,
                divisions: 10,
                label: "Volume ${(_volume * 100).round()}%",
                onChanged: _changeVolume,
              ),
            ],
          ),
      ],
    );
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }
}

class VoltarMenuButton extends StatelessWidget {
  const VoltarMenuButton({super.key});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.brown,
        foregroundColor: Colors.amberAccent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        textStyle: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
      child: const Text('Voltar ao Menu'),
    );
  }
}
